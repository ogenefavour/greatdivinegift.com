<?php
session_start();
//getting session variables for all pages
$_SESSION['school_id'] = 1;
$school_id = $_SESSION['school_id'];


?>

 
