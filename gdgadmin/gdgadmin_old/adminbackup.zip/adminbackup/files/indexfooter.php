<!DOCTYPE html>
<footer class="main-footer">
    <div class="container-fluid">
        <div class="pull-right hidden-xs">
          <b>Version</b> 1.0
        </div>
          <strong>Copyright &copy; 2018 <a href="https://nexgen.com">ne<b>X</b>gen</a>.</strong> All rights
        reserved.
    </div>
    <!-- /.container -->
</footer>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="assets/js/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="assets/js/bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="assets/js/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="assets/js/fastclick.js"></script>
<script src="assets/js/parsley.min.js" type="text/javascript"></script>
<!-- AdminLTE App -->
<script src="assets/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="assets/js/demo.js"></script>
<script src="assets/js/jquery-ui.min.js" type="text/javascript"></script>
<script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
</body>
</html>