<!DOCTYPE html>
    <footer class="main-footer no-print">
        <div class="container-fluid">
          <div class="pull-right hidden-xs">
            <b>Version</b> 1.0
          </div>
            <strong>Copyright &copy; 2018 <a href="https://nexgen.com">ne<b>X</b>gen</a>.</strong> All rights
          reserved.
        </div>
        <!-- /.container -->
    </footer>
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
    <div class="control-sidebar-bg"></div>

</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="../assets/js/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="../assets/js/bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="../assets/js/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="../assets/js/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="../assets/js/adminlte.min.js"></script>
<script src="../assets/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="../assets/js/dataTables.bootstrap.min.js" type="text/javascript"></script>
<!-- AdminLTE for demo purposes -->
<script src="../assets/js/demo.js"></script>
<script src="../assets/js/jquery-ui.min.js" type="text/javascript"></script>
<script src="../plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
<script src="../assets/js/select2.full.min.js" type="text/javascript"></script>
<!--<script src="../assets/js/moment.min.js" type="text/javascript"></script>-->
<script src="../plugins/input-mask/jquery.inputmask.extensions.js" type="text/javascript"></script>
<script src="../plugins/input-mask/jquery.inputmask.date.extensions.js" type="text/javascript"></script>
<script src="../plugins/input-mask/jquery.inputmask.js" type="text/javascript"></script>
<script src="../assets/js/bootstrap-timepicker.min.js" type="text/javascript"></script>
<script src="../assets/js/bootstrap-datepicker.min.js" type="text/javascript"></script>
<script src="../plugins/iCheck/icheck.min.js" type="text/javascript"></script>
